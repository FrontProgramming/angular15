import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CCS } from '../ccs_service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})

export class SignupComponent implements OnInit {
  @Output() event = new EventEmitter<any>();

  constructor(
    private country: CCS,
    ) {
  }

  title = "Registration Form";
  userForm!: FormGroup;
  stateInfo: any = [];
  countryInfo: any = [];
  cityInfo: any = [];
  gender: any = [
    { value: 'Male', viewValue: 'Male' },
    { value: 'Female', viewValue: 'Female' }
  ];
  Firstname: any;

  ngOnInit(): void {
    this.getCountries();

    this.userForm = new FormGroup({
      firstname: new FormControl('', [Validators.required, Validators.minLength(2)]),
      lastname: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      sex: new FormControl('null', Validators.required),
      mobile: new FormControl('', Validators.required),
      userAddress: new FormControl('', Validators.required),
      userLandmark: new FormControl('', Validators.required),
      userCountry: new FormControl('null', Validators.required),
      userState: new FormControl('', Validators.required),
      userCity: new FormControl('', Validators.required),
      userZipcode: new FormControl('', [Validators.required])
    });
  }

  getCountries() {
    this.country.allCountries().subscribe((data2: { Countries: any; }) => {
      this.countryInfo = data2.Countries;
    }, (err: any) => console.log(err), () => console.log('complete'))
  }

  onChangeCountry(countryValue: any) {
    this.stateInfo = this.countryInfo[countryValue].States;
    this.cityInfo = this.stateInfo[0].Cities;
  }

  onChangeState(stateValue: any) {
    this.cityInfo = this.stateInfo[stateValue].Cities;
  }

  submitForm(data:any): void {
    // console.log(JSON.stringify(this.userForm.value));
    // console.log(this.userForm.value);
    console.log(this.userForm.get('value'));
    // this.userForm = data.userForm;
  }

  get EmailFirstname(): FormControl {
    return this.userForm.get('firstname') as FormControl;
  }
  get Lastname(): FormControl {
    return this.userForm.get('lastname') as FormControl;
  }
  get Sex(): FormControl {
    return this.userForm.get('sex') as FormControl;
  }
  get Email(): FormControl {
    return this.userForm.get('email') as FormControl;
  }
  get Mobile(): FormControl {
    return this.userForm.get('mobile') as FormControl;
  }
  get Password(): FormControl {
    return this.userForm.get('password') as FormControl;
  }
  get Address(): FormControl {
    return this.userForm.get('userAddress') as FormControl;
  }
  get Landmark(): FormControl {
    return this.userForm.get('userLandmark') as FormControl;
  }
  get Country(): FormControl {
    return this.userForm.get('userCountry') as FormControl;
  }
  get City(): FormControl {
    return this.userForm.get('userCity') as FormControl;
  }
  get State(): FormControl {
    return this.userForm.get('userState') as FormControl;
  }
  get Zipcode(): FormControl {
    return this.userForm.get('userZipcode') as FormControl;
  }

}

